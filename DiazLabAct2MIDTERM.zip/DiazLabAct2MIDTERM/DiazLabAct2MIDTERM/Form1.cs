﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace DiazLabAct2MIDTERM
{
    public partial class Form1 : Form
    {
        public List<char> operandStack;
        public Stack<char> operatorStack;
        List<char> origStack = new List<char>();
        Dictionary<char, int> sortedStack = new Dictionary<char, int>();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string output = InFixToPostFix(textBox1.Text);
                textBox2.Text = output;
            }
            catch (Exception ex)
            {
                textBox2.Text = ex.Message;
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string output = InfixToPrefix(textBox1.Text);
                textBox2.Text = output;
            }
            catch (Exception ex)
            {
                textBox2.Text = ex.Message;
            }
        }

        private string InFixToPostFix(string source)
        {
            string output = "";
            operandStack = new List<char>();
            operatorStack = new Stack<char>();
            origStack = new List<char>();
            sortedStack = new Dictionary<char, int>();

            foreach (char node in source)
            {
                if (char.IsNumber(node))//operand
                {
                    output += node;
                    //operandStack.Add(node);
                    if (operandStack.Count > 0)
                    {
                        int level = GetPrecedence(operandStack.First());
                        if (level >= 2)
                        {
                            output += operatorStack.Pop();
                        }
                    }
                }
                else //operator
                {
                    if (GetPrecedence(node) == 0)
                    {
                        throw new Exception("Your expression has an invalid operator!");
                    }

                    if (GetPrecedence(node) == 4)
                    {
                        throw new Exception("Parenthesis are not yet supported!");
                    }
                    operatorStack.Push(node);
                }
            }

            while (operatorStack.Count > 0)
            {
                output += operatorStack.Pop();
            }


            return output;
        }

        private string InfixToPrefix(string source)
        {
            string revsrc = string.Join("", source.Reverse());
            string output = InFixToPostFix(revsrc);
            return string.Join("", output.Reverse());
        }

        private int GetPrecedence(char oprtor)//MDAS Level
        {
            switch (oprtor)
            {

                case '(':
                case ')':
                    return 4;
                    break;
                case '^':
                    return 3;
                    break;
                case '*':
                case '/':
                    return 2;
                case '-':
                case '+':
                    return 1;
                    break;
                default:
                    return 0;
                    break;

            }
        }

        private Stack<char> SortStack()//MDAS Level
        {
            origStack = operatorStack.ToList();
            foreach (char node in origStack)
            {
                sortedStack.Add(node, GetPrecedence(node));//+
            }
            Dictionary<char, int> sortedDict = sortedStack.OrderByDescending(x => x.Value).ToDictionary(x => x.Key, x => x.Value); ;

            Stack<char> newSortedStack = new Stack<char>();
            foreach (char node in sortedDict.Keys)
            {
                newSortedStack.Push(node);
            }

            return newSortedStack;
        }
    }
}