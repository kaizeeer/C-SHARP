﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PreFinalApp
{
    public class StudentGrid
    {
        public int Id { get; set; } // Id (Primary key)
        public string LastName { get; set; } // LastName (length: 10)
        public string FirstName { get; set; } // FirstName (length: 10)
        public string EmailAddress { get; set; } // EmailAddress (length: 10)
        public string StudentId { get; set; } // StudentID (length: 10)
        
    }
}
